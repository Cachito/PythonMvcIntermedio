"""
Constantes de posicion de campos
'Id', 'Fecha', 'Medio', 'Sección', 'Título', 'Cuerpo'
"""
ID_NOTICIA = 0
FECHA = 1
MEDIO = 2
SECCION = 3
TITULO = 4
CUERPO = 5
